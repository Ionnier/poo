#ifndef JUDET_H
#define JUDET_H
enum Judet {
    Alba = 1, Arad, Arges, Bacau, Bihor,
    BistritaNasaud, Botosani, Brasov, Braila, Buzau,
    CarasSeverin, Cluj, Constanta, Covasna, Dambovita,
    Dolj, Galati, Gorj, Harghita, Hunedoara,
    Ialomita, Iasi, Ilfov, Maramures, Mehedinti,
    Mures, Neamt, Olt, Prahova, SatuMare,
    Salaj, Sibiu, Suceava, Teleorman, Timis,
    Tulcea, Vaslui, Valcea, Vrancea, Bucuresti,
    BucurestiSector1, BucurestiSector2, BucurestiSector3,
    BucurestiSector4, BucurestiSector5, BucurestiSector6,
    Calarasi = 51, Giurgiu
};
#endif //JUDET_H
